# OMADMS Prototype (Frontend)

Interactive click-through UI/UX prototype built in React + Tailwind CSS.

## Run locally
npm install
npm run dev

## Build for deployment
npm run build
